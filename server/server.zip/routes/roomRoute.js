const express = require('express');
const { createRoom, joinRoom, getRoomById, getAllPublicRooms } = require('../controllers/roomController');
const { protectRoute } = require('../controllers/authController');
const router = express.Router();

router.route('/').post(protectRoute, createRoom);
router.route('/:roomId').post( joinRoom);
router.route('/public').get( getAllPublicRooms);
router.route('/:id').get(protectRoute, getRoomById);


module.exports = router;