import { useEffect, useRef, useState } from 'react';
import { Stage, Layer, Line } from 'react-konva';
import { useParams } from 'react-router-dom';
import { useSocket } from '../context/SocketContext';
import { useSelector } from 'react-redux';

export default function RoomDetail() {
    const socket = useSocket();
    const [strokes, setStrokes] = useState([]);
    const { id: roomId } = useParams();
    const isDrawing = useRef(false);
    const { user } = useSelector(state => state.auth);
    
    useEffect(() => {
        if (!socket) return;
        console.log('🔌 Socket ready:', socket.id);
        const join = () => socket.emit('join-room', roomId, user._id);
        join();

        socket.on('drawing', stroke => {
            console.log('← received stroke', stroke.stroke);
            setStrokes(prev => [...prev, stroke.stroke]);
        });
        return () => socket.off('drawing');
    }, [socket, roomId, user._id]);

    const handleMouseDown = e => {
        console.log('mouse down');
        isDrawing.current = true;
        const pos = e.target.getStage().getPointerPosition();
        setStrokes(prev => [
            ...prev,
            { points: [pos.x, pos.y], color: 'black', strokeWidth: 2 }
        ]);
    };

    const handleMouseMove = e => {
        if (!isDrawing.current) return;
        console.log('mouse move');
        const stage = e.target.getStage();
        const pos = stage.getPointerPosition();

        setStrokes(prev => {
            const last = prev[prev.length - 1];
            last.points = last.points.concat([pos.x, pos.y]);
            if (socket) {
                console.log('→ emitting stroke', last);
                socket.emit('drawing', { roomId, stroke: last });
            }
            return [...prev.slice(0, -1), last];
        });
    };

    const handleMouseUp = () => {
        console.log('mouse up');
        isDrawing.current = false;
    };

    return (
        <div style={{ width: '100vw', height: '100vh' }}>
        <Stage
            width={window.innerWidth}
            height={window.innerHeight}
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
            style={{ cursor: 'crosshair' }}
        >
            <Layer>
            {strokes.map((s, i) => (
                <Line
                key={i}
                points={s.points}
                stroke={s.color}
                strokeWidth={s.strokeWidth}
                tension={0.5}
                lineCap="round"
                />
            ))}
            </Layer>
        </Stage>
        </div>
    );
}
